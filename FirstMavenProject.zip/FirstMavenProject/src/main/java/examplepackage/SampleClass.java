package examplepackage;

public class SampleClass {
	public static void main(String[] args) {
	System.out.println("Hello this is my new Maven Project");
	}
}
